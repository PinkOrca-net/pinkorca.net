<?php
$host = "162.55.240.80";
$user = "pinkorc2_pinkorca";
$password = "AliMazloom1234";
$msg_db = "pinkorc2_msgs";
