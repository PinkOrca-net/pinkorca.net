<!-- Footer -->
<footer class="ucs -mx-4 flex flex-col-reverse justify-between gap-2 items-center p-4 bg-slate-900 text-[#f4abc4] sm:flex-row">
    <span>سپاس از همراهی شما :)</span>
    <span dir="ltr">2021 - &infin;</span>
    <span>ساخته شده با &hearts; توسط پینک اورکا</span>
</footer>